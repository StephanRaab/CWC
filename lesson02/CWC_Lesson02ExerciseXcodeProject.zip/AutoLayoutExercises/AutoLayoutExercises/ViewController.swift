//
//  ViewController.swift
//  AutoLayoutExercises
//
//  Created by Christopher Ching on 2019-02-11.
//  Copyright © 2019 Christopher Ching. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

